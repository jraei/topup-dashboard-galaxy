
<style>
:root {
    /* Primary Colors */
    --color-primary: <?php echo e(\App\Models\WebConfig::get('primary_color', '#9b87f5')); ?>;
    --color-primary-rgb: <?php echo e(\App\Models\WebConfig::hexToRgb(App\Models\WebConfig::get('primary_color', '#9b87f5'))); ?>;
    --color-primary-hover: <?php echo e(\App\Models\WebConfig::get('primary_hover', '#818CF8')); ?>;
    --color-primary-hover-rgb: <?php echo e(\App\Models\WebConfig::hexToRgb(App\Models\WebConfig::get('primary_hover', '#818CF8'))); ?>;

    /* Secondary Colors */
    --color-secondary: <?php echo e(\App\Models\WebConfig::get('secondary_color', '#33C3F0')); ?>;
    --color-secondary-rgb: <?php echo e(\App\Models\WebConfig::hexToRgb(App\Models\WebConfig::get('secondary_color', '#33C3F0'))); ?>;
    --color-secondary-hover: <?php echo e(\App\Models\WebConfig::get('secondary_hover', '#A78BFA')); ?>;
    --color-secondary-hover-rgb: <?php echo e(\App\Models\WebConfig::hexToRgb(\App\Models\WebConfig::get('secondary_hover', '#A78BFA'))); ?>;

    /* Text Colors */
    --color-text-primary: <?php echo e(\App\Models\WebConfig::get('text_primary', '#F9FAFB')); ?>;
    --color-text-secondary: <?php echo e(\App\Models\WebConfig::get('text_secondary', '#E5E7EB')); ?>;

    /* Background Colors */
    --color-header-bg: <?php echo e(\App\Models\WebConfig::get('header_bg', '#111827')); ?>;
    --color-footer-bg: <?php echo e(\App\Models\WebConfig::get('footer_bg', '#111827')); ?>;
    --color-content-bg: <?php echo e(\App\Models\WebConfig::get('content_bg', '#1F2937')); ?>;
}
</style>
<?php /**PATH D:\laragon\www\project-topup-10\resources\views/partials/color-vars.blade.php ENDPATH**/ ?>